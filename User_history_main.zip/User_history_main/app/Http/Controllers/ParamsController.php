<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ParamsController extends Controller
{
    const SUCCESS = 'success';
    const ERROR = 'error';
    const WARNING = 'warning';
}
